# ⚖️ AutoMizan — Açık Kaynaklı Mali Müşavir Muhasebe Otomasyon Motoru

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg)](https://fastapi.tiangolo.com)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.32+-FF4B4B.svg)](https://streamlit.io)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Tests: Pytest](https://img.shields.io/badge/Tests-100%25%20Passed-brightgreen.svg)]()

**AutoMizan**, Türkiye'deki mali müşavirler, muhasebe büroları ve finans ekipleri için geliştirilmiş uçtan uca açık kaynaklı ve sıfır maliyetli bir ön muhasebe otomasyon motorudur. 

Çok modlu girdi belgelerini (**UBL-TR e-Fatura/e-Arşiv XML**, dijital/taranmış **PDF**, **Fiş fotoğrafları**, **Banka ekstreleri**) deterministik ve yerel OCR yöntemleriyle ayrıştırır; **Tek Düzen Hesap Planına (TDHP)** göre çift taraflı (Borç / Alacak) yevmiye fişlerine dönüştürür ve **TÜRMOB LUCA**, **Logo Netsis**, **SAP** formatlarında dışa aktarır.

---

## ✨ Temel Özellikler

- ⚡ **Çok Modlu Veri Ayrıştırma (Sıfır Maliyet Mimarisi):**
  - **UBL-TR XML:** `xml.etree` ile 5 ms'de sıfır maliyetle matrah, KDV kırılımları ve cari verisi çekimi.
  - **Dijital PDF:** `PyMuPDF` ile saniyeler içinde hatasız metin ayrıştırma.
  - **Taranmış Fiş / Belge:** Yerel `Tesseract OCR (Türkçe Modeli)` ile %100 çevrimdışı, gizli ve ücretsiz OCR.
  - **Banka Ekstreleri:** Excel/CSV ekstrelerindeki hareketleri otomatik kolon eşleme ile okuma.
- 📐 **Tek Düzen Hesap Planı (TDHP) Muhasebeleştirme:**
  - Alış / Satış ayrımı ve KDV (%1, %10, %20) alt hesapları (`191.01`, `191.10`, `191.20`, `391.01`, `391.10`, `391.20`).
  - Tedarikçi/Müşteri carileri (`320.XXXX`, `120.XXXX`).
  - Harcama kategorilerine göre akıllı hesap tahmini (`770.03` Taşıt/Akaryakıt, `770.05` Yemek, `760.01` Kargo, `770.02` Kırtasiye, `153.01` Ticari Mallar).
  - Kuruş farkı toleranslı otomatik denge kontrolü ($\sum \text{Borç} = \sum \text{Alacak}$).
- 📤 **ERP ve Muhasebe Entegrasyon Çıktıları:**
  - **TÜRMOB LUCA:** "Excel'den Fiş Aktarımı" ile %100 uyumlu Excel ve e-Fiş XML şablonları.
  - **Logo Netsis:** NDI / Fiş aktarım şablonu.
  - **SAP:** FB01 / F-02 (40 Borç, 50 Alacak) Batch Input ve Excel yükleme formatı.
- 🧠 **Mali Müşavir Kural Motoru (Hafıza):**
  - Özel cari ve harcama anahtar kelimelerini sisteme öğreterek sonraki işlemlerde otomatik atama yapabilme.

---

## 🚀 Kurulum ve Çalıştırma

### 1. Depoyu Klonlayın
```bash
git clone https://github.com/kullanici-adiniz/automizan.git
cd automizan
```

### 2. Bağımlılıkları Yükleyin
```bash
pip install -r requirements.txt
```

### 3. Uygulamayı Başlatın

#### Web Arayüzü (Önerilen):
```bash
python -m streamlit run automizan/arayuz/app.py
```
*(Tarayıcınızda `http://localhost:8501` adresine gidin.)*

#### REST API Sunucusu:
```bash
python -m uvicorn automizan.api.sunucu:app --reload --port 8000
```
*(Swagger dökümantasyonu: `http://localhost:8000/docs`)*

#### Windows Tek Tıkla Başlatma:
Depo içerisindeki `AutoMizan.cmd` dosyasına çift tıklayarak doğrudan başlatabilirsiniz.

---

## 🐳 Docker ile Çalıştırma

```bash
docker-compose up -d
```
Servisler `http://localhost:8501` (Arayüz) ve `http://localhost:8000` (API) üzerinde ayağa kalkar.

---

## 🧪 Testler

Motorun tüm testlerini çalıştırmak için:
```bash
pytest automizan/test_automizan.py -v
```

---

## 📄 Lisans

Bu proje [MIT Lisansı](LICENSE) kapsamında açık kaynak olarak lisanslanmıştır.
