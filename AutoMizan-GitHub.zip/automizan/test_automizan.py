"""
AutoMizan - Birim ve Entegrasyon Testleri
UBL-TR XML, TDHP muhasebe motoru, bakiye eşitliği ve ERP aktarımlarını test eder.
"""
from decimal import Decimal
import pytest
from automizan.motor.modeller import (
    CanonicalInvoice,
    TaxSubtotal,
    InvoiceLineItem
)
from automizan.motor.ayristirici.ubl_tr import UBLTRParser
from automizan.motor.ayristirici.pdf_ocr import PDFandOCRParser
from automizan.motor.muhasebe.tdhp_motoru import TDHPEngine
from automizan.motor.ihracat.luca import LucaExporter
from automizan.motor.ihracat.netsis import NetsisExporter
from automizan.motor.ihracat.sap import SAPExporter


SAMPLE_UBL_TR_XML = """<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:ID>GIB2024000000001</cbc:ID>
  <cbc:IssueDate>2024-05-15</cbc:IssueDate>
  <cbc:InvoiceTypeCode>SATIS</cbc:InvoiceTypeCode>
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyIdentification><cbc:ID>1234567890</cbc:ID></cac:PartyIdentification>
      <cac:PartyName><cbc:Name>PETROL OFİSİ A.Ş.</cbc:Name></cac:PartyName>
    </cac:Party>
  </cac:AccountingSupplierParty>
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyIdentification><cbc:ID>9876543210</cbc:ID></cac:PartyIdentification>
      <cac:PartyName><cbc:Name>ORNEK YAZILIM LTD. STI.</cbc:Name></cac:PartyName>
    </cac:Party>
  </cac:AccountingCustomerParty>
  <cac:TaxTotal>
    <cac:TaxSubtotal>
      <cbc:TaxableAmount>1000.00</cbc:TaxableAmount>
      <cbc:TaxAmount>200.00</cbc:TaxAmount>
      <cbc:Percent>20.0</cbc:Percent>
    </cac:TaxSubtotal>
  </cac:TaxTotal>
  <cac:LegalMonetaryTotal>
    <cbc:PayableAmount>1200.00</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>
  <cac:InvoiceLine>
    <cbc:InvoicedQuantity>50.0</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount>1000.00</cbc:LineExtensionAmount>
    <cac:Item><cbc:Name>Motorin Yakıt</cbc:Name></cac:Item>
    <cac:Price><cbc:PriceAmount>20.00</cbc:PriceAmount></cac:Price>
  </cac:InvoiceLine>
</Invoice>
"""


def test_ubl_tr_parser():
    inv = UBLTRParser.parse_string(SAMPLE_UBL_TR_XML, filename="test.xml")
    assert inv.invoice_number == "GIB2024000000001"
    assert inv.issue_date == "2024-05-15"
    assert inv.supplier_title == "PETROL OFİSİ A.Ş."
    assert inv.payable_amount == Decimal("1200.00")
    assert len(inv.tax_subtotals) == 1
    assert inv.tax_subtotals[0].taxable_amount == Decimal("1000.00")
    assert inv.tax_subtotals[0].tax_amount == Decimal("200.00")
    assert inv.tax_subtotals[0].tax_percent == Decimal("20.0")


def test_tdhp_purchase_journal_voucher():
    inv = UBLTRParser.parse_string(SAMPLE_UBL_TR_XML, filename="test.xml")
    voucher = TDHPEngine.generate_journal_voucher(inv)

    assert voucher.is_balanced is True
    assert voucher.total_debit == voucher.total_credit == Decimal("1200.00")

    # Akaryakıt kuralı devrede olmalı -> 770.03
    account_codes = [line.account_code for line in voucher.lines]
    assert "770.03" in account_codes
    assert "191.20" in account_codes
    assert "320.7890" in account_codes


def test_tdhp_sales_journal_voucher():
    sales_inv = CanonicalInvoice(
        invoice_number="ABC2024000000002",
        issue_date="2024-05-16",
        invoice_type="SATIS",
        customer_vkn_tckn="1122334455",
        customer_title="MÜŞTERİ TİCARET A.Ş.",
        payable_amount=Decimal("6000.00"),
        tax_subtotals=[
            TaxSubtotal(taxable_amount=Decimal("5000.00"), tax_amount=Decimal("1000.00"), tax_percent=Decimal("20.0"))
        ]
    )
    voucher = TDHPEngine.generate_journal_voucher(sales_inv)
    assert voucher.is_balanced is True
    assert voucher.total_debit == Decimal("6000.00")
    assert voucher.total_credit == Decimal("6000.00")

    account_codes = [line.account_code for line in voucher.lines]
    assert "120.4455" in account_codes
    assert "600.20" in account_codes
    assert "391.20" in account_codes


def test_pdf_ocr_text_parser():
    sample_text = """
    TÜRK TELEKOMÜNİKASYON A.Ş.
    VERGİ KİMLİK NO: 8765432109
    FATURA NO: ETT2024000001234
    TARİH: 10.06.2024
    TOPLAM MATRAH: 1.000,00 TL
    HESAPLANAN KDV: 200,00 TL
    ÖDENECEK TUTAR: 1.200,00 TL
    """
    inv = PDFandOCRParser.parse_text(sample_text, filename="fatura.pdf")
    assert inv.invoice_number == "ETT2024000001234"
    assert inv.issue_date == "2024-06-10"
    assert inv.payable_amount == Decimal("1200.00")
    assert inv.tax_subtotals[0].tax_amount == Decimal("200.00")

    voucher = TDHPEngine.generate_journal_voucher(inv)
    assert voucher.is_balanced is True
    assert "770.07" in [l.account_code for l in voucher.lines]  # Telekom


def test_erp_exports():
    inv = UBLTRParser.parse_string(SAMPLE_UBL_TR_XML)
    voucher = TDHPEngine.generate_journal_voucher(inv)

    # LUCA Excel
    luca_bytes = LucaExporter.to_excel([voucher])
    assert len(luca_bytes) > 1000

    # LUCA XML
    luca_xml = LucaExporter.to_xml([voucher])
    assert "<LucaFisAktarim>" in luca_xml

    # Netsis Excel
    netsis_bytes = NetsisExporter.to_excel([voucher])
    assert len(netsis_bytes) > 1000

    # SAP FB01
    sap_csv = SAPExporter.to_fb01_csv([voucher])
    assert "BLDAT;BLART;BUKRS" in sap_csv
    assert ";40;" in sap_csv
    assert ";50;" in sap_csv
