"""
AutoMizan - FastAPI REST API Sunucusu
Dosya kabul, çok modlu ayrıştırma, TDHP yevmiye oluşturma ve ERP aktarım uç noktaları.
"""
import os
import tempfile
from typing import List, Dict, Any
from fastapi import FastAPI, UploadFile, File, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from automizan.motor.modeller import (
    CanonicalInvoice,
    JournalVoucher
)
from automizan.motor.ayristirici.ubl_tr import UBLTRParser
from automizan.motor.ayristirici.pdf_ocr import PDFandOCRParser, LOCAL_TESSERACT_EXE
from automizan.motor.ayristirici.excel_ekstre import ExcelStatementParser
from automizan.motor.muhasebe.tdhp_motoru import TDHPEngine
from automizan.motor.ihracat.luca import LucaExporter
from automizan.motor.ihracat.netsis import NetsisExporter
from automizan.motor.ihracat.sap import SAPExporter


app = FastAPI(
    title="AutoMizan Engine API",
    description="Mali Müşavirler için Sıfır Maliyetli Muhasebe Otomasyon Motoru",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class CustomRuleRequest(BaseModel):
    keyword: str
    account_code: str
    account_name: str


class ProcessingResponse(BaseModel):
    invoices: List[CanonicalInvoice]
    vouchers: List[JournalVoucher]
    summary: Dict[str, Any]


@app.get("/api/v1/saglik")
def health_check():
    ocr_active = os.path.exists(LOCAL_TESSERACT_EXE)
    return {
        "durum": "aktif",
        "surum": "1.0.0",
        "tesseract_ocr": "hazır" if ocr_active else "bulunamadı",
        "tesseract_yolu": LOCAL_TESSERACT_EXE
    }


@app.get("/api/v1/kurallar")
def get_rules():
    return {
        "varsayilan_kurallar": TDHPEngine.EXPENSE_RULES,
        "ozel_kurallar": TDHPEngine.custom_rules
    }


@app.post("/api/v1/kurallar")
def add_custom_rule(rule: CustomRuleRequest):
    TDHPEngine.register_custom_rule(rule.keyword, rule.account_code, rule.account_name)
    return {"mesaj": f"'{rule.keyword}' kuralı {rule.account_code} hesabına başarıyla kaydedildi."}


@app.post("/api/v1/isle", response_model=ProcessingResponse)
async def process_files(files: List[UploadFile] = File(...)):
    """PDF, XML, Excel veya Fiş görsellerini tek seferde toplu olarak işler."""
    parsed_invoices: List[CanonicalInvoice] = []
    generated_vouchers: List[JournalVoucher] = []

    for file in files:
        filename = file.filename
        ext = os.path.splitext(filename)[1].lower()
        content = await file.read()

        try:
            if ext == ".xml":
                invoice = UBLTRParser.parse_string(content.decode("utf-8", errors="ignore"), filename=filename)
                parsed_invoices.append(invoice)
                voucher = TDHPEngine.generate_journal_voucher(invoice)
                generated_vouchers.append(voucher)

            elif ext in [".xlsx", ".xls", ".csv"]:
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                    tmp.write(content)
                    tmp_path = tmp.name

                invoices = ExcelStatementParser.parse_file(tmp_path)
                for inv in invoices:
                    inv.source_filename = filename
                    parsed_invoices.append(inv)
                    voucher = TDHPEngine.generate_journal_voucher(inv)
                    generated_vouchers.append(voucher)

                try:
                    os.remove(tmp_path)
                except Exception:
                    pass

            elif ext in [".pdf", ".png", ".jpg", ".jpeg"]:
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                    tmp.write(content)
                    tmp_path = tmp.name

                text = PDFandOCRParser.extract_text_from_file(tmp_path)
                invoice = PDFandOCRParser.parse_text(text, filename=filename)
                parsed_invoices.append(invoice)
                voucher = TDHPEngine.generate_journal_voucher(invoice)
                generated_vouchers.append(voucher)

                try:
                    os.remove(tmp_path)
                except Exception:
                    pass

        except Exception as e:
            # Hata oluşsa bile diğer dosyaları işlemeye devam et
            continue

    total_debit = sum(v.total_debit for v in generated_vouchers)
    total_credit = sum(v.total_credit for v in generated_vouchers)
    all_balanced = all(v.is_balanced for v in generated_vouchers)

    return ProcessingResponse(
        invoices=parsed_invoices,
        vouchers=generated_vouchers,
        summary={
            "toplam_dosya": len(files),
            "basarili_fis": len(generated_vouchers),
            "toplam_borc": float(total_debit),
            "toplam_alacak": float(total_credit),
            "tum_fisler_dengeli": all_balanced
        }
    )


@app.post("/api/v1/disa-aktar/luca")
def export_luca(vouchers: List[JournalVoucher]):
    data = LucaExporter.to_excel(vouchers)
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=luca_fis_listesi.xlsx"}
    )


@app.post("/api/v1/disa-aktar/netsis")
def export_netsis(vouchers: List[JournalVoucher]):
    data = NetsisExporter.to_excel(vouchers)
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=netsis_fis_listesi.xlsx"}
    )


@app.post("/api/v1/disa-aktar/sap")
def export_sap(vouchers: List[JournalVoucher]):
    data = SAPExporter.to_excel(vouchers)
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=sap_fb01_upload.xlsx"}
    )
