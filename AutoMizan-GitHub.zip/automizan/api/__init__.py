"""API paketi"""
from automizan.api.sunucu import app

__all__ = ["app"]
