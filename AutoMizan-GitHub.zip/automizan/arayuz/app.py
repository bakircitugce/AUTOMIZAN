"""
AutoMizan - Mali Müşavir Akıllı Muhasebe ve Fiş Otomasyon Paneli
Streamlit tabanlı modern, yerel ve sıfır maliyetli web arayüzü.
"""
import os
import sys
import tempfile
from decimal import Decimal
import pandas as pd
import streamlit as st

# Proje ana dizinini sys.path'e ekle
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(CURRENT_DIR))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from automizan.motor.modeller import CanonicalInvoice, JournalVoucher, TaxSubtotal, JournalEntryLine
from automizan.motor.ayristirici.ubl_tr import UBLTRParser
from automizan.motor.ayristirici.pdf_ocr import PDFandOCRParser, LOCAL_TESSERACT_EXE
from automizan.motor.ayristirici.excel_ekstre import ExcelStatementParser
from automizan.motor.muhasebe.tdhp_motoru import TDHPEngine
from automizan.motor.ihracat.luca import LucaExporter
from automizan.motor.ihracat.netsis import NetsisExporter
from automizan.motor.ihracat.sap import SAPExporter


# Sayfa Ayarları
st.set_page_config(
    page_title="AutoMizan — Mali Müşavir Muhasebe Otomasyonu",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Özel CSS ile Premium Fintek Tasarımı
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #64748b;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 15px;
        text-align: center;
    }
    .badge-balanced {
        background-color: #dcfce7;
        color: #166534;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
    }
    .badge-unbalanced {
        background-color: #fee2e2;
        color: #991b1b;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


# Durum Yönetimi (Session State)
if "vouchers" not in st.session_state:
    st.session_state.vouchers = []
if "invoices" not in st.session_state:
    st.session_state.invoices = []


# Yan Menü (Sidebar)
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/accounting.png", width=64)
    st.title("AutoMizan v1.0")
    st.markdown("**Fintek & Yapay Zekâ Muhasebe Motoru**")
    st.divider()

    ocr_durum = "✅ Hazır (Yerel)" if os.path.exists(LOCAL_TESSERACT_EXE) else "⚠️ Bulunamadı"
    st.markdown(f"**Tesseract OCR:** {ocr_durum}")
    st.markdown("**Ayrıştırma:** UBL-TR, PDF, OCR, Excel")
    st.markdown("**Hedef ERP:** LUCA, Netsis, SAP")

    st.divider()
    st.subheader("💡 Hızlı Demo")
    if st.button("🧪 Örnek Fatura Seti Yükle", use_container_width=True):
        # Demo Faturalar Üret
        sample_inv1 = CanonicalInvoice(
            invoice_number="GIB2026000000101",
            issue_date="2026-10-10",
            invoice_type="ALIS",
            supplier_vkn_tckn="1234567890",
            supplier_title="OPET PETROLCÜLÜK A.Ş.",
            payable_amount=Decimal("2400.00"),
            tax_subtotals=[
                TaxSubtotal(taxable_amount=Decimal("2000.00"), tax_amount=Decimal("400.00"), tax_percent=Decimal("20.0"))
            ],
            source_filename="demo_opet_yakit.xml"
        )
        sample_inv2 = CanonicalInvoice(
            invoice_number="ABC2026000000202",
            issue_date="2026-10-09",
            invoice_type="ALIS",
            supplier_vkn_tckn="9876543210",
            supplier_title="YURTİÇİ KARGO SERVİSİ A.Ş.",
            payable_amount=Decimal("600.00"),
            tax_subtotals=[
                TaxSubtotal(taxable_amount=Decimal("500.00"), tax_amount=Decimal("100.00"), tax_percent=Decimal("20.0"))
            ],
            source_filename="demo_yurtici_kargo.pdf"
        )
        sample_inv3 = CanonicalInvoice(
            invoice_number="SAT2026000000303",
            issue_date="2026-10-08",
            invoice_type="SATIS",
            customer_vkn_tckn="5554443322",
            customer_title="ACME MÜHENDİSLİK LTD. ŞTİ.",
            payable_amount=Decimal("12000.00"),
            tax_subtotals=[
                TaxSubtotal(taxable_amount=Decimal("10000.00"), tax_amount=Decimal("2000.00"), tax_percent=Decimal("20.0"))
            ],
            source_filename="demo_satis_faturasi.xml"
        )

        st.session_state.invoices = [sample_inv1, sample_inv2, sample_inv3]
        st.session_state.vouchers = [
            TDHPEngine.generate_journal_voucher(sample_inv1),
            TDHPEngine.generate_journal_voucher(sample_inv2),
            TDHPEngine.generate_journal_voucher(sample_inv3)
        ]
        st.success("3 adet örnek fatura ve yevmiye fişi yüklendi!")

    if st.button("🗑️ Listeyi Temizle", use_container_width=True):
        st.session_state.vouchers = []
        st.session_state.invoices = []
        st.rerun()


# Ana Başlık
st.markdown('<div class="main-header">⚖️ AutoMizan — Ön Muhasebe & Fiş Otomasyonu</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">UBL-TR XML, PDF, Fiş Görselleri ve Banka Ekstrelerini Tek Düzen Hesap Planına (TDHP) Göre Yevmiyeleştirin.</div>', unsafe_allow_html=True)


# Sekmeler
tab_islem, tab_kurallar, tab_hakkinda = st.tabs(["📑 Fiş İşleme & Aktarım", "🧠 Mali Müşavir Kural Motoru", "ℹ️ Sistem Mimarisi"])


with tab_islem:
    # 1. Dosya Yükleme Bölümü
    uploaded_files = st.file_uploader(
        "Faturaları, Fişleri veya Ekstreleri Yükleyin (Çoklu Seçim Desteklenir)",
        type=["xml", "pdf", "png", "jpg", "jpeg", "xlsx", "xls", "csv"],
        accept_multiple_files=True,
        help="GİB e-Fatura/e-Arşiv XML dosyaları, PDF faturalar, taranmış fotoğraflar veya Excel ekstreleri."
    )

    if uploaded_files:
        if st.button("⚡ Belgeleri Çözümle ve Fişleri Oluştur", type="primary"):
            new_vouchers = []
            new_invoices = []

            progress_bar = st.progress(0, text="Belgeler ayrıştırılıyor...")
            total = len(uploaded_files)

            for i, f in enumerate(uploaded_files):
                filename = f.name
                ext = os.path.splitext(filename)[1].lower()
                content = f.read()

                try:
                    if ext == ".xml":
                        inv = UBLTRParser.parse_string(content.decode("utf-8", errors="ignore"), filename=filename)
                        vouch = TDHPEngine.generate_journal_voucher(inv)
                        new_invoices.append(inv)
                        new_vouchers.append(vouch)

                    elif ext in [".xlsx", ".xls", ".csv"]:
                        with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                            tmp.write(content)
                            tmp_path = tmp.name
                        invs = ExcelStatementParser.parse_file(tmp_path)
                        for inv in invs:
                            inv.source_filename = filename
                            vouch = TDHPEngine.generate_journal_voucher(inv)
                            new_invoices.append(inv)
                            new_vouchers.append(vouch)
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass

                    elif ext in [".pdf", ".png", ".jpg", ".jpeg"]:
                        with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                            tmp.write(content)
                            tmp_path = tmp.name
                        text = PDFandOCRParser.extract_text_from_file(tmp_path)
                        inv = PDFandOCRParser.parse_text(text, filename=filename)
                        vouch = TDHPEngine.generate_journal_voucher(inv)
                        new_invoices.append(inv)
                        new_vouchers.append(vouch)
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass

                except Exception as e:
                    st.error(f"'{filename}' işlenirken hata oluştu: {str(e)}")

                progress_bar.progress((i + 1) / total, text=f"{filename} işlendi...")

            st.session_state.invoices = new_invoices
            st.session_state.vouchers = new_vouchers
            st.success(f"{len(new_vouchers)} adet yevmiye fişi başarıyla oluşturuldu!")
            st.rerun()

    # 2. Özet Metrikler
    if st.session_state.vouchers:
        st.divider()
        tot_belge = len(st.session_state.vouchers)
        tot_borc = sum(v.total_debit for v in st.session_state.vouchers)
        tot_alacak = sum(v.total_credit for v in st.session_state.vouchers)
        hepsi_dengeli = all(v.is_balanced for v in st.session_state.vouchers)

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Toplam Yevmiye Fişi", f"{tot_belge} Adet")
        col2.metric("Toplam Borç", f"{tot_borc:,.2f} ₺")
        col3.metric("Toplam Alacak", f"{tot_alacak:,.2f} ₺")
        col4.metric(
            "Bakiye Dengesi (Borç = Alacak)",
            "DENGELİ ✅" if hepsi_dengeli else "DENGESİZ ❌",
            delta="Kuruş farkı yok" if hepsi_dengeli else "Lütfen kontrol edin"
        )

        st.divider()

        # 3. ERP Dışa Aktarma Butonları
        st.subheader("📤 Muhasebe Yazılımına Aktar")
        exp_col1, exp_col2, exp_col3 = st.columns(3)

        with exp_col1:
            luca_bytes = LucaExporter.to_excel(st.session_state.vouchers)
            st.download_button(
                label="📥 LUCA e-Fiş (Excel) İndir",
                data=luca_bytes,
                file_name="luca_fis_aktarim.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
                type="primary"
            )

        with exp_col2:
            netsis_bytes = NetsisExporter.to_excel(st.session_state.vouchers)
            st.download_button(
                label="📥 Logo Netsis (Excel) İndir",
                data=netsis_bytes,
                file_name="netsis_fis_listesi.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )

        with exp_col3:
            sap_bytes = SAPExporter.to_excel(st.session_state.vouchers)
            st.download_button(
                label="📥 SAP FB01 (Excel) İndir",
                data=sap_bytes,
                file_name="sap_fb01_upload.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )

        st.divider()

        # 4. Yevmiye Fişleri Listesi & Düzenleme
        st.subheader("📋 Oluşturulan Yevmiye Fişleri")

        for idx, voucher in enumerate(st.session_state.vouchers, start=1):
            denge_rozet = "✅ Dengeli" if voucher.is_balanced else "❌ Dengesiz"
            with st.expander(f"Fiş #{idx}: {voucher.voucher_date} | {voucher.description} ({denge_rozet})", expanded=(idx == 1)):
                # Tablo oluştur
                rows = []
                for line in voucher.lines:
                    rows.append({
                        "Hesap Kodu": line.account_code,
                        "Hesap Adı": line.account_name,
                        "Borç (TL)": float(line.debit) if line.debit > 0 else 0.0,
                        "Alacak (TL)": float(line.credit) if line.credit > 0 else 0.0,
                        "Açıklama": line.description,
                        "Evrak No": line.document_no
                    })
                df_lines = pd.DataFrame(rows)

                st.dataframe(
                    df_lines,
                    use_container_width=True,
                    column_config={
                        "Borç (TL)": st.column_config.NumberColumn(format="%.2f ₺"),
                        "Alacak (TL)": st.column_config.NumberColumn(format="%.2f ₺"),
                    },
                    hide_index=True
                )

                st.caption(f"Kaynak Belge: `{voucher.source_filename or 'Doğrudan Giriş'}` | Toplam Borç: **{voucher.total_debit:,.2f} ₺** | Toplam Alacak: **{voucher.total_credit:,.2f} ₺**")

    else:
        st.info("👆 Lütfen yukarıdan fatura yükleyin veya sol taraftaki 'Örnek Fatura Seti Yükle' butonuna tıklayarak sistemi test edin.")


with tab_kurallar:
    st.subheader("🧠 Akıllı Mali Müşavir Kuralları ve Hafızası")
    st.markdown("Belirli cari veya açıklamalarda otomatik atanmasını istediğiniz TDHP hesap kodlarını buradan belirleyebilirsiniz.")

    kural_col1, kural_col2 = st.columns([1, 1])

    with kural_col1:
        st.markdown("#### ➕ Yeni Kural Ekle")
        with st.form("yeni_kural_formu"):
            yeni_kelime = st.text_input("Anahtar Kelime veya Cari Ünvan", placeholder="Örn: Migros, Metro, Starbucks")
            yeni_kod = st.text_input("TDHP Hesap Kodu", placeholder="Örn: 770.05")
            yeni_ad = st.text_input("Hesap Adı", placeholder="Örn: Personel Mutfak ve İkram Giderleri")
            kaydet_btn = st.form_submit_button("Kuralı Kaydet")

            if kaydet_btn and yeni_kelime and yeni_kod and yeni_ad:
                TDHPEngine.register_custom_rule(yeni_kelime, yeni_kod, yeni_ad)
                st.success(f"'{yeni_kelime}' için {yeni_kod} hesabı hafızaya alındı!")

    with kural_col2:
        st.markdown("#### 📚 Mevcut Kural Listesi")
        kural_data = []
        for kw, (k, a) in TDHPEngine.custom_rules.items():
            kural_data.append({"Tip": "Özel Kural", "Kelime / Cari": kw, "Hesap Kodu": k, "Hesap Adı": a})
        for kw, (k, a) in list(TDHPEngine.EXPENSE_RULES.items())[:10]:
            kural_data.append({"Tip": "Varsayılan", "Kelime / Cari": kw, "Hesap Kodu": k, "Hesap Adı": a})

        df_kurallar = pd.DataFrame(kural_data)
        st.dataframe(df_kurallar, use_container_width=True, hide_index=True)


with tab_hakkinda:
    st.subheader("🏛️ Sıfır Maliyetli Sistem Mimarisi")
    st.markdown("""
    - **Ayrıştırma (Parser):**
        - UBL-TR e-Fatura/e-Arşiv: `xml.etree` (Sıfır maliyet, anlık)
        - Dijital PDF: `PyMuPDF` (Hızlı metin katmanı çıkarma)
        - Taranmış Evrak/Görüntü: Yerleşik `Tesseract OCR (TR Modeli)` ile %100 çevrimdışı ve gizli.
    - **Muhasebeleştirme (Engine):**
        - VUK & Tek Düzen Hesap Planı standartlarına tam uyum.
        - %1, %10, %20 KDV kırılımları (191 ve 391 hesaplar).
        - 120 / 320 Cari kodlama ve kuruş toleranslı bakiye denetimi.
    - **Entegrasyonlar:**
        - TÜRMOB LUCA e-Fiş Excel & XML şablonları.
        - Logo Netsis Toplu Fiş şablonu.
        - SAP FB01 / F-02 Batch Input yükleme şablonu.
    """)
