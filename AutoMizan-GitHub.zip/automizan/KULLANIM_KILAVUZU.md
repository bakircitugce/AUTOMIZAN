# ⚖️ AutoMizan — Mali Müşavir Akıllı Muhasebe Motoru

AutoMizan; Türkiye'deki mali müşavirler, muhasebe ofisleri ve KOBİ'ler için geliştirilmiş; **UBL-TR XML, dijital/taranmış PDF, fiş görselleri ve banka ekstrelerini** sıfır maliyetle analiz edip **Tek Düzen Hesap Planına (TDHP)** uygun çift taraflı (Borç / Alacak) yevmiye fişlerine dönüştüren ve **LUCA, Netsis, SAP** sistemlerine aktaran açık kaynaklı SaaS motorudur.

---

## 🚀 Hızlı Başlangıç

### 1. Masaüstünden Başlatma (Tek Tıkla)
Ana dizindeki [`AutoMizan.cmd`](file:///c:/Users/turha/Downloads/C/parity-calistir-main/AutoMizan.cmd) dosyasına çift tıklayarak web panelini tarayıcınızda açabilirsiniz:
- **Web Paneli Adresi:** `http://localhost:8501`

### 2. Komut Satırından Başlatma
```bash
# Web Arayüzünü Başlatma (Streamlit)
python -m streamlit run automizan/arayuz/app.py

# REST API Sunucusunu Başlatma (FastAPI)
python -m uvicorn automizan.api.sunucu:app --reload --port 8000
```

---

## 📁 Proje Dizin Yapısı

```
automizan/
├── motor/                          # Çekirdek Muhasebe ve Ayrıştırma Motoru
│   ├── modeller.py                 # Kanonik Fatura ve Yevmiye Veri Modelleri (Pydantic)
│   ├── ayristirici/
│   │   ├── ubl_tr.py               # GİB e-Fatura / e-Arşiv XML Ayrıştırıcı (0 Maliyet)
│   │   ├── pdf_ocr.py              # PyMuPDF + Yerel Tesseract OCR (TR Modeli)
│   │   └── excel_ekstre.py         # Banka Ekstresi & Excel Fatura Ayrıştırıcı
│   ├── muhasebe/
│   │   └── tdhp_motoru.py          # TDHP Kural Motoru, KDV (%1,%10,%20), 120/320 Eşleme
│   └── ihracat/
│       ├── luca.py                 # TÜRMOB LUCA e-Fiş Excel & XML Aktarım Şablonu
│       ├── netsis.py               # Logo Netsis Excel Transfer Şablonu
│       └── sap.py                  # SAP FB01 / F-02 Batch Input & Excel Şablonu
├── api/
│   └── sunucu.py                   # FastAPI REST API Uç Noktaları
├── arayuz/
│   └── app.py                      # Modern Streamlit Web Arayüzü
├── ornekler/                       # Test için hazır örnek XML ve CSV ekstre dosyaları
│   ├── ornek_efatura.xml
│   └── ornek_ekstre.csv
├── test_automizan.py               # Otomatik Pytest Birim ve Entegrasyon Testleri
└── KULLANIM_KILAVUZU.md
```

---

## 🛠️ Temel Yetenekler

### 1. Çok Modlu Sıfır Maliyetli Giriş (Multimodal Ingestion)
- **UBL-TR XML:** Deterministik `xml.etree` parser'ı ile 5 milisaniyede tüm matrah, KDV kırılımları ve cari bilgileri sıfır maliyetle ayrıştırılır.
- **PDF & Fiş Görselleri:** Dijital PDF'ler `PyMuPDF` ile anında okunur; taranmış kağıt fatura ve fişlerde ise sistemde yerleşik bulunan yerel `Tesseract OCR (TR)` motoru devreye girer.
- **Banka Ekstreleri:** Excel/CSV ekstrelerindeki hareketler otomatik kolon tespitiyle fiş satırlarına dönüştürülür.

### 2. TDHP Muhasebeleştirme Kuralları
- **Alış Faturaları:**
  - Borç: `770` / `153` (Akaryakıt, yemek, kırtasiye, konaklama, haberleşme vb. kategorilerine göre alt hesap)
  - Borç: `191.01` (%1), `191.10` (%10), `191.20` (%20) İndirilecek KDV
  - Alacak: `320.XXXX` Satıcı Cari Hesabı
- **Satış Faturaları:**
  - Borç: `120.XXXX` Alıcı Cari Hesabı
  - Alacak: `600.XX` Yurtiçi Satışlar
  - Alacak: `391.01`, `391.10`, `391.20` Hesaplanan KDV
- **Bakiye Dengesi:** $\sum \text{Borç} = \sum \text{Alacak}$ eşitliği kuruş farkı toleransı ($\pm 0.05$ TL) ile denetlenir; farklar `679/689` hesapları ile dengelenir.

### 3. ERP Dışa Aktarımları (Export)
- **TÜRMOB LUCA:** "Fiş İşlemleri -> Excel'den Fiş Aktarımı" menüsüne doğrudan yüklenebilir Excel ve XML.
- **Logo Netsis:** NDI / Fiş Transfer şablonu.
- **SAP:** FB01 / F-02 standart kayıt anahtarları (40 Borç, 50 Alacak) ile CSV ve Excel formatı.

---

## 🧪 Testleri Çalıştırma

Tüm motoru test etmek için:
```bash
python -m pytest automizan/test_automizan.py -v
```
*(5 test: UBL-TR, Alış/Satış TDHP, PDF/OCR, ERP Dışa Aktarım testleri %100 başarıyla geçmektedir.)*
