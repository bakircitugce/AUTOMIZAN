"""Muhasebe kuralları paketi"""
from automizan.motor.muhasebe.tdhp_motoru import TDHPEngine

__all__ = ["TDHPEngine"]
