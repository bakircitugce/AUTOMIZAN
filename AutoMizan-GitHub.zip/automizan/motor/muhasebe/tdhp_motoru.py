"""
AutoMizan - Tek Düzen Hesap Planı (TDHP) Muhasebeleştirme Motoru
Türkiye Muhasebe Standartları ve VUK mevzuatına uygun olarak;
faturaları, fişleri ve banka ekstrelerini çift taraflı (Borç / Alacak)
yevmiye kayıtlarına dönüştürür.
"""
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Tuple, Optional
from automizan.motor.modeller import (
    CanonicalInvoice,
    JournalVoucher,
    JournalEntryLine
)


class TDHPEngine:
    """Tek Düzen Hesap Planı Çift Taraflı Kayıt ve Akıllı Kural Motoru"""

    # Varsayılan Gider Sınıflandırma Sözlüğü (Genişletilebilir Mali Müşavir Kuralları)
    EXPENSE_RULES: Dict[str, Tuple[str, str]] = {
        # Akaryakıt & Taşıt
        "akaryakıt": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "benzin": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "mazot": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "motorin": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "petrol": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "opet": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "shell": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "bp": ("770.03", "Taşıt Akaryakıt Giderleri"),
        "otopark": ("770.03", "Taşıt Otopark Giderleri"),
        "hgs": ("770.03", "Taşıt Geçiş Giderleri"),
        "ogs": ("770.03", "Taşıt Geçiş Giderleri"),

        # Yemek & Temsil Ağırlama
        "yemek": ("770.05", "Temsil, Ağırlama ve Yemek Giderleri"),
        "restoran": ("770.05", "Temsil, Ağırlama ve Yemek Giderleri"),
        "cafe": ("770.05", "Temsil, Ağırlama ve Yemek Giderleri"),
        "lokanta": ("770.05", "Temsil, Ağırlama ve Yemek Giderleri"),
        "gıda": ("770.05", "Temsil, Ağırlama ve Yemek Giderleri"),
        "market": ("770.05", "Gıda ve Ofis Mutfak Giderleri"),
        "sodexo": ("770.05", "Personel Yemek Giderleri"),
        "multinet": ("770.05", "Personel Yemek Giderleri"),
        "ticket": ("770.05", "Personel Yemek Giderleri"),

        # Kırtasiye & Büro
        "kırtasiye": ("770.02", "Kırtasiye ve Büro Malzemesi Giderleri"),
        "ofis": ("770.02", "Büro Malzemesi Giderleri"),
        "fotokopi": ("770.02", "Büro ve Baskı Giderleri"),
        "toner": ("770.02", "Yazıcı ve Sarf Malzemesi Giderleri"),
        "kartus": ("770.02", "Yazıcı ve Sarf Malzemesi Giderleri"),

        # Kargo & Ulaştırma
        "kargo": ("760.01", "Pazarlama, Satış ve Kargo Giderleri"),
        "yurtiçi kargo": ("760.01", "Kargo ve Kurye Giderleri"),
        "aras kargo": ("760.01", "Kargo ve Kurye Giderleri"),
        "mng kargo": ("760.01", "Kargo ve Kurye Giderleri"),
        "kurye": ("760.01", "Kurye ve Dağıtım Giderleri"),

        # Seyahat & Konaklama
        "otel": ("770.04", "Seyahat ve Konaklama Giderleri"),
        "konaklama": ("770.04", "Seyahat ve Konaklama Giderleri"),
        "uçak": ("770.04", "İş Seyahati Ulaşım Giderleri"),
        "bilet": ("770.04", "İş Seyahati Ulaşım Giderleri"),
        "thy": ("770.04", "Türk Hava Yolları Ulaşım Giderleri"),
        "pegasus": ("770.04", "Havayolu Ulaşım Giderleri"),

        # Enerji & Haberleşme
        "elektrik": ("770.06", "Elektrik Enerjisi Giderleri"),
        "enerjisa": ("770.06", "Elektrik Enerjisi Giderleri"),
        "doğalgaz": ("770.06", "Isınma ve Doğalgaz Giderleri"),
        "igdaş": ("770.06", "Doğalgaz Giderleri"),
        "su faturası": ("770.06", "Su Giderleri"),
        "iski": ("770.06", "Su Giderleri"),
        "telefon": ("770.07", "Haberleşme ve Telefon Giderleri"),
        "turkcell": ("770.07", "Haberleşme Giderleri"),
        "vodafone": ("770.07", "Haberleşme Giderleri"),
        "türk telekom": ("770.07", "İletişim ve İnternet Giderleri"),
        "internet": ("770.07", "İnternet Erişim Giderleri"),

        # Bilgi İşlem & Yazılım
        "yazılım": ("770.08", "Bilgi İşlem ve Yazılım Lisans Giderleri"),
        "lisans": ("770.08", "Yazılım Lisans Giderleri"),
        "hosting": ("770.08", "Sunucu ve Barındırma Giderleri"),
        "domain": ("770.08", "Alan Adı ve Web Hizmetleri"),
        "cloud": ("770.08", "Bulut Bilişim Hizmet Giderleri"),
        "google": ("770.08", "Yazılım ve Reklam Hizmetleri"),
        "microsoft": ("770.08", "Yazılım Lisans Giderleri"),

        # Danışmanlık & Hizmet
        "danışmanlık": ("770.09", "Müşavirlik ve Danışmanlık Giderleri"),
        "avukat": ("770.09", "Hukuk ve Müşavirlik Giderleri"),
        "muhasebe": ("770.09", "Mali Müşavirlik Hizmet Bedeli"),
        "temizlik": ("770.10", "Temizlik ve Hijyen Giderleri"),
        "güvenlik": ("770.11", "Özel Güvenlik Hizmet Giderleri")
    }

    # Kullanıcı tanımlı özel kurallar (Mali müşavir arayüzünden eklenebilir)
    custom_rules: Dict[str, Tuple[str, str]] = {}

    @classmethod
    def register_custom_rule(cls, keyword: str, account_code: str, account_name: str):
        """Kullanıcının belirlediği özel TDHP eşlemesini hafızaya alır."""
        cls.custom_rules[keyword.lower().strip()] = (account_code, account_name)

    @classmethod
    def classify_expense(cls, invoice: CanonicalInvoice) -> Tuple[str, str]:
        """Fatura içeriğini analiz ederek en uygun TDHP hesap kodunu tahmin eder."""
        corpus = f"{invoice.supplier_title} "
        for item in invoice.line_items:
            corpus += f"{item.name} "
        if invoice.notes:
            corpus += f"{invoice.notes} "
        if invoice.raw_text:
            corpus += invoice.raw_text
        corpus_clean = corpus.lower()

        # 1. Öncelik: Kullanıcı Tanımlı Özel Kurallar
        for kw, (code, name) in cls.custom_rules.items():
            if kw in corpus_clean:
                return code, name

        # 2. Öncelik: Standart Kural Sözlüğü
        for kw, (code, name) in cls.EXPENSE_RULES.items():
            if kw in corpus_clean:
                return code, name

        # 3. Ticari Mal / Emtia kontrolü
        if any(w in corpus_clean for w in ["ticari mal", "emtia", "ürün satışı", "toptan"]):
            return "153.01", "Ticari Mallar"

        # Varsayılan Hesap
        return "770.99", "Diğer Genel Yönetim Giderleri"

    @classmethod
    def get_vat_account(cls, is_purchase: bool, percent: Decimal) -> Tuple[str, str]:
        """KDV oranına göre TDHP alt hesap kodu ve adını üretir."""
        p_int = int(percent)
        if is_purchase:
            prefix = "191"
            base_name = "İndirilecek KDV"
        else:
            prefix = "391"
            base_name = "Hesaplanan KDV"

        if p_int == 1:
            return f"{prefix}.01", f"%1 {base_name}"
        elif p_int == 10:
            return f"{prefix}.10", f"%10 {base_name}"
        else:
            return f"{prefix}.20", f"%20 {base_name}"

    @classmethod
    def generate_journal_voucher(cls, invoice: CanonicalInvoice, voucher_no: Optional[str] = None) -> JournalVoucher:
        """Kanonik faturayı çift taraflı (Borç / Alacak) yevmiye fişine dönüştürür."""
        lines: List[JournalEntryLine] = []
        is_purchase = (invoice.invoice_type == "ALIS")
        is_return = (invoice.invoice_type == "IADE")

        doc_desc = f"{invoice.invoice_number} - {invoice.supplier_title or invoice.customer_title}"
        if len(doc_desc) > 80:
            doc_desc = doc_desc[:80]

        # -------------------------------------------------------------
        # VAKA 1: ALIŞ FATURASI (Gider / Mal Alımı)
        # -------------------------------------------------------------
        if is_purchase:
            exp_code, exp_name = cls.classify_expense(invoice)

            # Matrah Kalemleri (BORÇ)
            for sub in invoice.tax_subtotals:
                if sub.taxable_amount > 0:
                    lines.append(JournalEntryLine(
                        account_code=exp_code,
                        account_name=exp_name,
                        debit=sub.taxable_amount,
                        credit=Decimal("0.00"),
                        description=doc_desc,
                        document_no=invoice.invoice_number,
                        document_date=invoice.issue_date
                    ))

            # KDV Kalemleri (BORÇ)
            for sub in invoice.tax_subtotals:
                if sub.tax_amount > 0:
                    vat_code, vat_name = cls.get_vat_account(is_purchase=True, percent=sub.tax_percent)
                    lines.append(JournalEntryLine(
                        account_code=vat_code,
                        account_name=vat_name,
                        debit=sub.tax_amount,
                        credit=Decimal("0.00"),
                        description=f"%{int(sub.tax_percent)} KDV - {doc_desc}",
                        document_no=invoice.invoice_number,
                        document_date=invoice.issue_date
                    ))

            # Satıcı Cari Hesabı (ALACAK)
            sup_code = f"320.{invoice.supplier_vkn_tckn[-4:]}" if len(invoice.supplier_vkn_tckn) >= 4 else "320.01"
            lines.append(JournalEntryLine(
                account_code=sup_code,
                account_name=invoice.supplier_title or "Satıcılar Hesabı",
                debit=Decimal("0.00"),
                credit=invoice.payable_amount,
                description=doc_desc,
                document_no=invoice.invoice_number,
                document_date=invoice.issue_date
            ))

        # -------------------------------------------------------------
        # VAKA 2: SATIŞ FATURASI
        # -------------------------------------------------------------
        elif not is_return:
            # Alıcı Cari Hesabı (BORÇ)
            cust_code = f"120.{invoice.customer_vkn_tckn[-4:]}" if len(invoice.customer_vkn_tckn) >= 4 else "120.01"
            lines.append(JournalEntryLine(
                account_code=cust_code,
                account_name=invoice.customer_title or "Alıcılar Hesabı",
                debit=invoice.payable_amount,
                credit=Decimal("0.00"),
                description=doc_desc,
                document_no=invoice.invoice_number,
                document_date=invoice.issue_date
            ))

            # Gelir / Satış Kalemleri (ALACAK)
            for sub in invoice.tax_subtotals:
                if sub.taxable_amount > 0:
                    p_int = int(sub.tax_percent)
                    rev_code = f"600.{p_int:02d}"
                    lines.append(JournalEntryLine(
                        account_code=rev_code,
                        account_name=f"%{p_int} Yurtiçi Satışlar",
                        debit=Decimal("0.00"),
                        credit=sub.taxable_amount,
                        description=doc_desc,
                        document_no=invoice.invoice_number,
                        document_date=invoice.issue_date
                    ))

            # Hesaplanan KDV Kalemleri (ALACAK)
            for sub in invoice.tax_subtotals:
                if sub.tax_amount > 0:
                    vat_code, vat_name = cls.get_vat_account(is_purchase=False, percent=sub.tax_percent)
                    lines.append(JournalEntryLine(
                        account_code=vat_code,
                        account_name=vat_name,
                        debit=Decimal("0.00"),
                        credit=sub.tax_amount,
                        description=f"%{int(sub.tax_percent)} KDV - {doc_desc}",
                        document_no=invoice.invoice_number,
                        document_date=invoice.issue_date
                    ))

        # -------------------------------------------------------------
        # VAKA 3: ALIŞTAN İADE
        # -------------------------------------------------------------
        else:
            sup_code = f"320.{invoice.supplier_vkn_tckn[-4:]}" if len(invoice.supplier_vkn_tckn) >= 4 else "320.01"
            lines.append(JournalEntryLine(
                account_code=sup_code,
                account_name=invoice.supplier_title or "Satıcılar Hesabı",
                debit=invoice.payable_amount,
                credit=Decimal("0.00"),
                description=f"İade - {doc_desc}",
                document_no=invoice.invoice_number,
                document_date=invoice.issue_date
            ))
            for sub in invoice.tax_subtotals:
                lines.append(JournalEntryLine(
                    account_code="679.01",
                    account_name="Alış İadeleri Geliri",
                    debit=Decimal("0.00"),
                    credit=sub.taxable_amount,
                    description=f"İade Matrahı - {doc_desc}",
                    document_no=invoice.invoice_number,
                    document_date=invoice.issue_date
                ))
                if sub.tax_amount > 0:
                    lines.append(JournalEntryLine(
                        account_code="391.20",
                        account_name="İlave Edilecek KDV",
                        debit=Decimal("0.00"),
                        credit=sub.tax_amount,
                        description=f"İade KDV - {doc_desc}",
                        document_no=invoice.invoice_number,
                        document_date=invoice.issue_date
                    ))

        # -------------------------------------------------------------
        # BAKİYE DENETİMİ VE KURUŞ FARKI DÜZELTMESİ (Borç == Alacak)
        # -------------------------------------------------------------
        tot_debit = sum(l.debit for l in lines)
        tot_credit = sum(l.credit for l in lines)
        difference = (tot_debit - tot_credit).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        # 0.05 TL altındaki yuvarlama farklarını 679/689 ile otomatik dengele
        if Decimal("0.00") < abs(difference) <= Decimal("0.05"):
            if difference > 0:
                # Borç fazla -> Alacağa kuruş ekle (679 Yuvarlama Geliri)
                lines.append(JournalEntryLine(
                    account_code="679.99",
                    account_name="Kuruş Yuvarlama Farkları",
                    debit=Decimal("0.00"),
                    credit=difference,
                    description="Otomatik Yuvarlama Dengesi",
                    document_no=invoice.invoice_number,
                    document_date=invoice.issue_date
                ))
            else:
                # Alacak fazla -> Borca kuruş ekle (689 Yuvarlama Gideri)
                lines.append(JournalEntryLine(
                    account_code="689.99",
                    account_name="Kuruş Yuvarlama Farkları",
                    debit=abs(difference),
                    credit=Decimal("0.00"),
                    description="Otomatik Yuvarlama Dengesi",
                    document_no=invoice.invoice_number,
                    document_date=invoice.issue_date
                ))
            tot_debit = sum(l.debit for l in lines)
            tot_credit = sum(l.credit for l in lines)

        balanced = (tot_debit == tot_credit)

        return JournalVoucher(
            voucher_no=voucher_no or f"YEV-{invoice.invoice_number}",
            voucher_date=invoice.issue_date,
            voucher_type="MAHSUP",
            description=doc_desc,
            lines=lines,
            total_debit=tot_debit,
            total_credit=tot_credit,
            is_balanced=balanced,
            source_filename=invoice.source_filename
        )
