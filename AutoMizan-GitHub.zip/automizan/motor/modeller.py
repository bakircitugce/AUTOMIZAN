"""
AutoMizan - Standart Veri Modelleri (Pydantic v2)
Çok modlu girdilerden elde edilen verileri ve TDHP yevmiye fişlerini temsil eder.
"""
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional
from pydantic import BaseModel, Field


class TaxSubtotal(BaseModel):
    taxable_amount: Decimal = Field(default=Decimal("0.00"), description="Vergi Matrahı")
    tax_amount: Decimal = Field(default=Decimal("0.00"), description="KDV Tutarı")
    tax_percent: Decimal = Field(default=Decimal("20.0"), description="KDV Oranı: 1, 10, 20")


class InvoiceLineItem(BaseModel):
    name: str = Field(..., description="Mal / Hizmet Adı")
    quantity: Decimal = Field(default=Decimal("1.0"), description="Miktar")
    unit_price: Decimal = Field(default=Decimal("0.0"), description="Birim Fiyat")
    line_total: Decimal = Field(default=Decimal("0.0"), description="Kalem Tutarı (KDV Hariç)")
    vat_percent: Decimal = Field(default=Decimal("20.0"), description="KDV Oranı")


class CanonicalInvoice(BaseModel):
    invoice_number: str = Field(..., description="Fatura / Fiş Numarası")
    issue_date: str = Field(..., description="Belge Tarihi (YYYY-MM-DD)")
    invoice_type: str = Field(default="ALIS", description="ALIS, SATIS, IADE")
    supplier_vkn_tckn: str = Field(default="", description="Satıcı VKN veya TCKN")
    supplier_title: str = Field(default="", description="Satıcı Ünvanı / Adı")
    customer_vkn_tckn: str = Field(default="", description="Alıcı VKN veya TCKN")
    customer_title: str = Field(default="", description="Alıcı Ünvanı / Adı")
    payable_amount: Decimal = Field(default=Decimal("0.00"), description="Ödenecek Tutar (Genel Toplam)")
    tax_subtotals: List[TaxSubtotal] = Field(default_factory=list, description="KDV Kırılımları")
    line_items: List[InvoiceLineItem] = Field(default_factory=list, description="Fatura Kalemleri")
    source_filename: Optional[str] = Field(default=None, description="Kaynak Dosya Adı")
    raw_text: Optional[str] = Field(default=None, description="Ham OCR / Metin İçeriği")
    notes: Optional[str] = Field(default="", description="Ek Açıklamalar / Notlar")


class JournalEntryLine(BaseModel):
    account_code: str = Field(..., description="TDHP Hesap Kodu (Örn: 191.20, 320.01, 770.03)")
    account_name: str = Field(..., description="Hesap Adı")
    debit: Decimal = Field(default=Decimal("0.00"), description="Borç Tutarı")
    credit: Decimal = Field(default=Decimal("0.00"), description="Alacak Tutarı")
    description: str = Field(..., description="Satır Açıklaması")
    document_no: str = Field(..., description="Evrak No")
    document_date: str = Field(..., description="Evrak Tarihi (YYYY-MM-DD)")


class JournalVoucher(BaseModel):
    voucher_no: Optional[str] = Field(default="", description="Fiş / Yevmiye Numarası")
    voucher_date: str = Field(..., description="Fiş Tarihi (YYYY-MM-DD)")
    voucher_type: str = Field(default="MAHSUP", description="MAHSUP, TAHSIL, TEDIYE")
    description: str = Field(..., description="Fiş Genel Açıklaması")
    lines: List[JournalEntryLine] = Field(default_factory=list, description="Yevmiye Satırları")
    total_debit: Decimal = Field(default=Decimal("0.00"), description="Toplam Borç")
    total_credit: Decimal = Field(default=Decimal("0.00"), description="Toplam Alacak")
    is_balanced: bool = Field(default=False, description="Borç == Alacak eşit mi?")
    source_filename: Optional[str] = Field(default=None, description="Kaynak Belge")
