"""
AutoMizan - PDF ve OCR Ayrıştırıcı
Dijital PDF'leri PyMuPDF ile anında okur.
Taranmış PDF ve görüntü dosyalarında (PNG, JPG) dahili Tesseract motorunu
kullanarak sıfır maliyetle Türkçe OCR yapar.
"""
import os
import re
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional
from automizan.motor.modeller import (
    CanonicalInvoice,
    TaxSubtotal,
    InvoiceLineItem
)

# Tesseract yerel yolunu yapılandır
WORKSPACE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
LOCAL_TESSERACT_EXE = os.path.join(WORKSPACE_DIR, "tesseract", "tesseract.exe")
LOCAL_TESSDATA = os.path.join(WORKSPACE_DIR, "tesseract", "tessdata")

try:
    import pytesseract
    if os.path.exists(LOCAL_TESSERACT_EXE):
        pytesseract.pytesseract.tesseract_cmd = LOCAL_TESSERACT_EXE
        os.environ["TESSDATA_PREFIX"] = LOCAL_TESSDATA
except ImportError:
    pytesseract = None


class PDFandOCRParser:
    """PDF ve Görüntü (Fiş/Makbuz) Ayrıştırıcı"""

    @classmethod
    def extract_text_from_file(cls, file_path: str) -> str:
        """Dosya tipine göre metin çıkarır (PDF veya Görüntü)."""
        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".pdf":
            return cls._extract_from_pdf(file_path)
        elif ext in [".png", ".jpg", ".jpeg", ".tiff", ".bmp"]:
            return cls._extract_from_image(file_path)
        return ""

    @classmethod
    def _extract_from_pdf(cls, pdf_path: str) -> str:
        text = ""
        # 1. Aşama: PyMuPDF ile dijital metin katmanını dene
        try:
            import pymupdf
            doc = pymupdf.open(pdf_path)
            for page in doc:
                text += page.get_text() + "\n"

            # Eğer sayfadan en az 50 karakter metin geldiyse dijital belgedir
            if len(text.strip()) > 50:
                return text
        except Exception:
            pass

        # 2. Aşama: Metin katmanı yoksa Taranmış Belgedir -> OCR yap
        if pytesseract and os.path.exists(LOCAL_TESSERACT_EXE):
            try:
                import pymupdf
                from PIL import Image
                doc = pymupdf.open(pdf_path)
                ocr_full = ""
                for page in doc:
                    pix = page.get_pixmap(dpi=200)
                    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                    ocr_full += pytesseract.image_to_string(img, lang="tur") + "\n"
                return ocr_full
            except Exception:
                pass

        return text

    @classmethod
    def _extract_from_image(cls, image_path: str) -> str:
        """Fiş veya fatura görüntüsünden Tesseract ile Türkçe metin okur."""
        if pytesseract and os.path.exists(LOCAL_TESSERACT_EXE):
            try:
                from PIL import Image
                img = Image.open(image_path)
                return pytesseract.image_to_string(img, lang="tur")
            except Exception:
                pass
        return ""

    @classmethod
    def parse_text(cls, text: str, filename: Optional[str] = None) -> CanonicalInvoice:
        """Metin içeriğini Türkçe fatura kurallarıyla analiz edip kanonik modele dönüştürür."""
        # 1. Fatura Numarası
        inv_no_match = re.search(r'\b([A-Z]{3}20\d{2}\d{9})\b', text)
        if inv_no_match:
            inv_no = inv_no_match.group(1)
        else:
            # Alternatif fiş no
            alt_match = re.search(r'(?:Fİ[ŞS]\s*NO|BELGE\s*NO)[\s:]*([A-Za-z0-9\-]+)', text, re.IGNORECASE)
            inv_no = alt_match.group(1) if alt_match else f"BELGE-{datetime.now().strftime('%Y%m%d%H%M')}"

        # 2. Belge Tarihi
        # Örn: 15.08.2024 veya 2024-08-15
        date_match = re.search(r'\b(\d{2})[./-](\d{2})[./-](20\d{2})\b', text)
        if date_match:
            issue_date = f"{date_match.group(3)}-{date_match.group(2)}-{date_match.group(1)}"
        else:
            iso_match = re.search(r'\b(20\d{2})[./-](\d{2})[./-](\d{2})\b', text)
            if iso_match:
                issue_date = f"{iso_match.group(1)}-{iso_match.group(2)}-{iso_match.group(3)}"
            else:
                issue_date = datetime.now().strftime('%Y-%m-%d')

        # 3. VKN / TCKN
        vkn_match = re.search(r'(?:VKN|TCKN|VERGİ\s*KİMLİK|VERGİ\s*NO)[\s:]*([0-9]{10,11})\b', text, re.IGNORECASE)
        vkn = vkn_match.group(1) if vkn_match else ""

        # 4. Firma Ünvanı (İlk 3 satır genelde firma adıdır)
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        supplier_title = "TANIMSIZ CARİ"
        if lines:
            for l in lines[:5]:
                if any(kw in l.upper() for kw in ["A.Ş", "LTD", "TİC", "SAN", "A.S", "PETROL", "MARKET", "HİZMET"]):
                    supplier_title = l
                    break
            if supplier_title == "TANIMSIZ CARİ" and len(lines) > 0:
                supplier_title = lines[0][:60]

        # 5. Sayısal Değerleri Çıkarma Yardımcısı
        def extract_amount(patterns: List[str]) -> Decimal:
            for pat in patterns:
                m = re.search(pat, text, re.IGNORECASE)
                if m:
                    clean = m.group(1).replace(' ', '').replace('.', '').replace(',', '.')
                    try:
                        return Decimal(clean).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    except Exception:
                        pass
            return Decimal("0.00")

        # Toplam Tutar
        payable = extract_amount([
            r'(?:ÖDENECEK\s*TUTAR|GENEL\s*TOPLAM|TOPLAM\s*TUTAR|KREDİ\s*KARTI|NAKİT|TOPLAM)[\s:*]*([0-9.,]+)',
            r'([0-9.,]+)\s*(?:TL|TRY)'
        ])

        # KDV Tutarı
        kdv = extract_amount([
            r'(?:HESAPLANAN\s*KDV|KDV\s*TUTARI|TOPLAM\s*KDV|KDV)[\s:*]*([0-9.,]+)'
        ])

        # Matrah
        matrah = extract_amount([
            r'(?:TOPLAM\s*MATRAH|MAL\s*HİZMET\s*TOPLAM|MATRAH)[\s:*]*([0-9.,]+)'
        ])

        # Tutarların tutarlılığını sağla
        if payable > 0 and matrah == 0 and kdv > 0:
            matrah = payable - kdv
        elif payable > 0 and kdv == 0 and matrah == 0:
            # Standart %20 KDV varsayımıyla iç yüzde hesabı
            # Matrah = Payable / 1.20
            matrah = (payable / Decimal("1.20")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            kdv = payable - matrah
        elif matrah > 0 and payable == 0:
            payable = matrah + kdv

        # KDV Oranı Tahmini
        tax_percent = Decimal("20.0")
        if matrah > 0 and kdv > 0:
            rate = (kdv / matrah * 100).quantize(Decimal("1"))
            if rate in [Decimal("1"), Decimal("10"), Decimal("20")]:
                tax_percent = rate

        subtotals = [
            TaxSubtotal(
                taxable_amount=matrah,
                tax_amount=kdv,
                tax_percent=tax_percent
            )
        ]

        return CanonicalInvoice(
            invoice_number=inv_no,
            issue_date=issue_date,
            invoice_type="ALIS",
            supplier_vkn_tckn=vkn,
            supplier_title=supplier_title,
            customer_vkn_tckn="",
            customer_title="",
            payable_amount=payable,
            tax_subtotals=subtotals,
            source_filename=filename,
            raw_text=text
        )
