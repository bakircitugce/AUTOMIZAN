"""
AutoMizan - Excel ve CSV Banka Ekstresi / Toplu Fatura Ayrıştırıcı
Pandas tabanlı; banka hareketlerini ve toplu fatura listelerini
otomatik kolon tanıma algoritmasıyla okur.
"""
import os
import re
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional
import pandas as pd
from automizan.motor.modeller import CanonicalInvoice, TaxSubtotal


class ExcelStatementParser:
    """Excel ve CSV Formatındaki Ekstre ve Fatura Listelerini Ayrıştırıcı"""

    DATE_COLS = ["tarih", "islem_tarihi", "işlem tarihi", "valör", "valor", "date"]
    DESC_COLS = ["açıklama", "aciklama", "islem_aciklamasi", "hareket", "description", "unvan", "ünvan"]
    AMOUNT_COLS = ["tutar", "tutar_tl", "amount", "borc", "alacak", "net_tutar", "toplam"]
    DOC_COLS = ["dekont_no", "fiş_no", "fatura_no", "evrak_no", "belge_no", "ref_no"]

    @classmethod
    def parse_file(cls, file_path: str) -> List[CanonicalInvoice]:
        """Excel veya CSV dosyasını okuyup CanonicalInvoice listesi döndürür."""
        ext = os.path.splitext(file_path)[1].lower()
        if ext in [".xlsx", ".xls"]:
            df = pd.read_excel(file_path)
        elif ext == ".csv":
            try:
                df = pd.read_csv(file_path, sep=";")
            except Exception:
                df = pd.read_csv(file_path, sep=",")
        else:
            return []

        return cls.parse_dataframe(df, os.path.basename(file_path))

    @classmethod
    def parse_dataframe(cls, df: pd.DataFrame, filename: str = "ekstre.xlsx") -> List[CanonicalInvoice]:
        # Kolon isimlerini küçült ve temizle
        col_map = {}
        for col in df.columns:
            clean = str(col).strip().lower().replace('ı', 'i').replace('ş', 's').replace('ç', 'c').replace('ğ', 'g').replace('ö', 'o').replace('ü', 'u')
            col_map[col] = clean

        df_clean = df.rename(columns=col_map)

        # Eşleşen kolonları bul
        date_col = next((c for c in df_clean.columns if any(k in c for k in ["tarih", "valor", "date"])), None)
        desc_col = next((c for c in df_clean.columns if any(k in c for k in ["aciklama", "unvan", "tanim", "desc"])), None)
        amt_col = next((c for c in df_clean.columns if any(k in c for k in ["tutar", "toplam", "borc", "amount"])), None)
        doc_col = next((c for c in df_clean.columns if any(k in c for k in ["dekont", "evrak", "belge", "fatura", "ref"])), None)

        invoices: List[CanonicalInvoice] = []

        for idx, row in df_clean.iterrows():
            raw_amt = row.get(amt_col, 0) if amt_col else 0
            if pd.isna(raw_amt):
                continue

            try:
                if isinstance(raw_amt, (int, float)):
                    amount = Decimal(str(abs(raw_amt))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                else:
                    clean_str = str(raw_amt).replace('.', '').replace(',', '.').strip()
                    amount = Decimal(clean_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            except Exception:
                continue

            if amount == 0:
                continue

            # Tarih dönüşümü
            raw_date = row.get(date_col, "") if date_col else ""
            date_str = str(raw_date)[:10] if not pd.isna(raw_date) else "2026-10-10"

            # Açıklama
            desc = str(row.get(desc_col, "Banka Hareketi")) if desc_col and not pd.isna(row.get(desc_col)) else "Banka Hareketi"
            doc_no = str(row.get(doc_col, f"BNK-{idx+1}")) if doc_col and not pd.isna(row.get(doc_col)) else f"BNK-{idx+1}"

            # Banka hareketi için KDV'siz (veya iç yüzde) model
            invoices.append(CanonicalInvoice(
                invoice_number=doc_no,
                issue_date=date_str,
                invoice_type="ALIS",
                supplier_vkn_tckn="",
                supplier_title=desc[:50],
                customer_vkn_tckn="",
                customer_title="",
                payable_amount=amount,
                tax_subtotals=[
                    TaxSubtotal(taxable_amount=amount, tax_amount=Decimal("0.00"), tax_percent=Decimal("0.0"))
                ],
                source_filename=filename,
                notes=desc
            ))

        return invoices
