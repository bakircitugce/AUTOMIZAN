"""Ayrıştırıcı alt paketi"""
from automizan.motor.ayristirici.ubl_tr import UBLTRParser
from automizan.motor.ayristirici.pdf_ocr import PDFandOCRParser
from automizan.motor.ayristirici.excel_ekstre import ExcelStatementParser

__all__ = ["UBLTRParser", "PDFandOCRParser", "ExcelStatementParser"]
