"""
AutoMizan - UBL-TR e-Fatura / e-Arşiv XML Ayrıştırıcı
GİB (Gelir İdaresi Başkanlığı) standart UBL-TR 1.2 şemasına uygun
deterministik ve sıfır maliyetli veri çıkarımı yapar.
"""
import xml.etree.ElementTree as ET
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional
from automizan.motor.modeller import (
    CanonicalInvoice,
    TaxSubtotal,
    InvoiceLineItem
)


class UBLTRParser:
    """GİB UBL-TR Formatı için Güçlendirilmiş XML Ayrıştırıcı"""

    NAMESPACES = {
        'cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
        'cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2'
    }

    @classmethod
    def _get_val(cls, element, path: str, default: str = "") -> str:
        """Belirtilen göreli yoldaki cbc/cac elementinin metin değerini döndürür."""
        if element is None:
            return default
        # Önce isim alanıyla ara
        found = element.find(path, cls.NAMESPACES)
        if found is not None and found.text:
            return found.text.strip()
        # İsim alanı yoksa veya başarısız olduysa yerel etiket adıyla dene
        clean_tag = path.split(':')[-1]
        for child in element:
            if child.tag.endswith(clean_tag) and child.text:
                return child.text.strip()
        return default

    @classmethod
    def parse_string(cls, xml_content: str, filename: Optional[str] = None) -> CanonicalInvoice:
        """XML metin içeriğini ayrıştırıp CanonicalInvoice nesnesi döndürür."""
        root = ET.fromstring(xml_content)
        return cls._parse_element(root, filename)

    @classmethod
    def parse_file(cls, file_path: str) -> CanonicalInvoice:
        """XML dosyasını okuyup ayrıştırır."""
        tree = ET.parse(file_path)
        root = tree.getroot()
        import os
        return cls._parse_element(root, os.path.basename(file_path))

    @classmethod
    def _parse_element(cls, root: ET.Element, filename: Optional[str] = None) -> CanonicalInvoice:
        # Fatura No, Tarih ve Profil
        inv_number = cls._get_val(root, 'cbc:ID', 'TANIMSIZ-NO')
        issue_date = cls._get_val(root, 'cbc:IssueDate', '')
        invoice_type_code = cls._get_val(root, 'cbc:InvoiceTypeCode', 'SATIS').upper()

        # Fatura Tipi (ALIS, SATIS, IADE vb.)
        inv_type = "IADE" if "IADE" in invoice_type_code else "ALIS"

        # 1. Tedarikçi (Satıcı) Bilgileri
        sup_party = root.find('cac:AccountingSupplierParty/cac:Party', cls.NAMESPACES)
        sup_vkn = ""
        sup_name = ""
        if sup_party is not None:
            sup_vkn = cls._get_val(sup_party.find('cac:PartyIdentification', cls.NAMESPACES), 'cbc:ID', '')
            sup_name = cls._get_val(sup_party.find('cac:PartyName', cls.NAMESPACES), 'cbc:Name', '')
            if not sup_name:
                # Şahıs şirketi ise Person/FirstName + FamilyName olabilir
                first = cls._get_val(sup_party.find('cac:Person', cls.NAMESPACES), 'cbc:FirstName', '')
                family = cls._get_val(sup_party.find('cac:Person', cls.NAMESPACES), 'cbc:FamilyName', '')
                sup_name = f"{first} {family}".strip()

        # 2. Müşteri (Alıcı) Bilgileri
        cust_party = root.find('cac:AccountingCustomerParty/cac:Party', cls.NAMESPACES)
        cust_vkn = ""
        cust_name = ""
        if cust_party is not None:
            cust_vkn = cls._get_val(cust_party.find('cac:PartyIdentification', cls.NAMESPACES), 'cbc:ID', '')
            cust_name = cls._get_val(cust_party.find('cac:PartyName', cls.NAMESPACES), 'cbc:Name', '')
            if not cust_name:
                first = cls._get_val(cust_party.find('cac:Person', cls.NAMESPACES), 'cbc:FirstName', '')
                family = cls._get_val(cust_party.find('cac:Person', cls.NAMESPACES), 'cbc:FamilyName', '')
                cust_name = f"{first} {family}".strip()

        # 3. Parasal Toplamlar (LegalMonetaryTotal)
        monetary = root.find('cac:LegalMonetaryTotal', cls.NAMESPACES)
        payable_str = cls._get_val(monetary, 'cbc:PayableAmount', '0.00')
        payable_amount = Decimal(payable_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        # 4. KDV Kırılımları (TaxTotal / TaxSubtotal)
        tax_subtotals: List[TaxSubtotal] = []
        for sub_elem in root.findall('cac:TaxTotal/cac:TaxSubtotal', cls.NAMESPACES):
            matrah_str = cls._get_val(sub_elem, 'cbc:TaxableAmount', '0.00')
            kdv_str = cls._get_val(sub_elem, 'cbc:TaxAmount', '0.00')
            percent_str = cls._get_val(sub_elem, 'cbc:Percent', '20.0')

            matrah = Decimal(matrah_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            kdv = Decimal(kdv_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            percent = Decimal(percent_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

            if matrah > 0 or kdv > 0:
                tax_subtotals.append(TaxSubtotal(
                    taxable_amount=matrah,
                    tax_amount=kdv,
                    tax_percent=percent
                ))

        # Eğer TaxSubtotal yoksa ama TaxTotal varsa genel matrahı hesapla
        if not tax_subtotals:
            tax_total_elem = root.find('cac:TaxTotal', cls.NAMESPACES)
            tot_kdv_str = cls._get_val(tax_total_elem, 'cbc:TaxAmount', '0.00')
            tot_kdv = Decimal(tot_kdv_str).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            matrah = payable_amount - tot_kdv
            tax_subtotals.append(TaxSubtotal(
                taxable_amount=max(matrah, Decimal("0.00")),
                tax_amount=tot_kdv,
                tax_percent=Decimal("20.0")
            ))

        # 5. Kalemler (InvoiceLine)
        line_items: List[InvoiceLineItem] = []
        for line_elem in root.findall('cac:InvoiceLine', cls.NAMESPACES):
            item_name = cls._get_val(line_elem.find('cac:Item', cls.NAMESPACES), 'cbc:Name', 'Mal / Hizmet')
            qty_str = cls._get_val(line_elem, 'cbc:InvoicedQuantity', '1.0')
            line_tot_str = cls._get_val(line_elem, 'cbc:LineExtensionAmount', '0.00')
            price_str = cls._get_val(line_elem.find('cac:Price', cls.NAMESPACES), 'cbc:PriceAmount', '0.00')
            vat_pct_str = cls._get_val(line_elem.find('cac:TaxTotal/cac:TaxSubtotal', cls.NAMESPACES), 'cbc:Percent', '20.0')

            line_items.append(InvoiceLineItem(
                name=item_name,
                quantity=Decimal(qty_str),
                unit_price=Decimal(price_str),
                line_total=Decimal(line_tot_str),
                vat_percent=Decimal(vat_pct_str)
            ))

        return CanonicalInvoice(
            invoice_number=inv_number,
            issue_date=issue_date,
            invoice_type=inv_type,
            supplier_vkn_tckn=sup_vkn,
            supplier_title=sup_name,
            customer_vkn_tckn=cust_vkn,
            customer_title=cust_name,
            payable_amount=payable_amount,
            tax_subtotals=tax_subtotals,
            line_items=line_items,
            source_filename=filename
        )
