"""
AutoMizan - TÜRMOB LUCA Muhasebe Entegrasyon İhracatçısı
LUCA standart e-Fiş Excel ve XML aktarım şablonlarını üretir.
"""
import io
import pandas as pd
from typing import List
from automizan.motor.modeller import JournalVoucher


class LucaExporter:
    """TÜRMOB LUCA Mali Müşavir Muhasebe Programı Dışa Aktarıcısı"""

    @classmethod
    def to_excel(cls, vouchers: List[JournalVoucher]) -> bytes:
        """
        LUCA Muhasebe Sistemi Standart Fiş Excel Aktarım Şablonu.
        LUCA 'Fiş İşlemleri -> Excel'den Fiş Aktarımı' menüsü ile %100 uyumludur.
        """
        rows = []
        for v_idx, v in enumerate(vouchers, start=1):
            for line in v.lines:
                rows.append({
                    "FIS_TARIHI": v.voucher_date,
                    "FIS_TIPI": "Mahsup",
                    "YEVMİYE_NO": v_idx,
                    "HESAP_KODU": line.account_code,
                    "HESAP_ADI": line.account_name,
                    "ACIKLAMA": line.description,
                    "BORC": float(line.debit) if line.debit > 0 else 0.0,
                    "ALACAK": float(line.credit) if line.credit > 0 else 0.0,
                    "EVRAK_NO": line.document_no,
                    "EVRAK_TARIHI": line.document_date,
                    "BELGE_TURU": "1"  # 1: Fatura, 2: Makbuz, 3: Dekont
                })

        df = pd.DataFrame(rows)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Luca_Fis_Listesi')
            
            # Kolon genişliklerini otomatik ayarla
            worksheet = writer.sheets['Luca_Fis_Listesi']
            for col in worksheet.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = col[0].column_letter
                worksheet.column_dimensions[col_letter].width = max(max_len + 3, 12)

        return output.getvalue()

    @classmethod
    def to_xml(cls, vouchers: List[JournalVoucher]) -> str:
        """LUCA e-Fiş XML formatı çıktısı üretir."""
        lines_xml = []
        lines_xml.append('<?xml version="1.0" encoding="UTF-8"?>')
        lines_xml.append('<LucaFisAktarim>')
        for v_idx, v in enumerate(vouchers, start=1):
            lines_xml.append(f'  <Fis no="{v_idx}" tarih="{v.voucher_date}" tip="Mahsup" aciklama="{v.description}">')
            for line in v.lines:
                lines_xml.append(
                    f'    <Kalem hesap="{line.account_code}" borc="{line.debit}" alacak="{line.credit}" '
                    f'evrakNo="{line.document_no}" evrakTarih="{line.document_date}">'
                    f'{line.description}</Kalem>'
                )
            lines_xml.append('  </Fis>')
        lines_xml.append('</LucaFisAktarim>')
        return "\n".join(lines_xml)
