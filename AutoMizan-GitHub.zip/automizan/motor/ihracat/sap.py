"""
AutoMizan - SAP ERP Entegrasyon İhracatçısı
SAP FB01 / F-02 ve BAPI_ACC_DOCUMENT_POST uyumlu veri formatları üretir.
"""
import io
import pandas as pd
from typing import List
from automizan.motor.modeller import JournalVoucher


class SAPExporter:
    """SAP Genel Muhasebe (FI) Fiş İhracatçısı"""

    @classmethod
    def to_fb01_csv(cls, vouchers: List[JournalVoucher], company_code: str = "1000") -> str:
        """SAP FB01 Doğrudan Kayıt CSV Şablonu (Kayıt Anahtarı: 40 Borç, 50 Alacak)"""
        buffer = io.StringIO()
        # Başlıklar: Belge Tarihi, Belge Türü, Şirket Kodu, Para Birimi, Kayıt Anahtarı, Hesap No, Tutar, Açıklama, Referans No
        buffer.write("BLDAT;BLART;BUKRS;WAERS;NEWBS;NEWKO;WRBTR;SGTXT;XBLNR\n")

        for v in vouchers:
            bldat = v.voucher_date.replace('-', '')
            for line in v.lines:
                posting_key = "40" if line.debit > 0 else "50"
                amount = float(line.debit if line.debit > 0 else line.credit)
                account_clean = line.account_code.replace('.', '')

                buffer.write(
                    f"{bldat};SA;{company_code};TRY;{posting_key};{account_clean};"
                    f"{amount:.2f};{line.description[:50]};{line.document_no}\n"
                )

        return buffer.getvalue()

    @classmethod
    def to_excel(cls, vouchers: List[JournalVoucher], company_code: str = "1000") -> bytes:
        """SAP Excel Upload Formatı"""
        rows = []
        for v in vouchers:
            for line in v.lines:
                rows.append({
                    "DOC_DATE": v.voucher_date,
                    "DOC_TYPE": "SA",
                    "COMP_CODE": company_code,
                    "CURRENCY": "TRY",
                    "POST_KEY": "40" if line.debit > 0 else "50",
                    "GL_ACCOUNT": line.account_code.replace('.', ''),
                    "AMOUNT": float(line.debit if line.debit > 0 else line.credit),
                    "ITEM_TEXT": line.description[:50],
                    "REF_DOC": line.document_no
                })

        df = pd.DataFrame(rows)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='SAP_FB01_Upload')
        return output.getvalue()
