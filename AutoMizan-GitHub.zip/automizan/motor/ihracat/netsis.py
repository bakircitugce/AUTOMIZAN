"""
AutoMizan - Logo Netsis Entegrasyon İhracatçısı
Netsis muhasebe modülü transfer formatına uygun Excel üretir.
"""
import io
import pandas as pd
from typing import List
from automizan.motor.modeller import JournalVoucher


class NetsisExporter:
    """Logo Netsis Muhasebe Fişi İhracatçısı"""

    @classmethod
    def to_excel(cls, vouchers: List[JournalVoucher]) -> bytes:
        """Netsis Toplu Fiş Girişi / NDI Aktarım Şablonu"""
        rows = []
        for v_idx, v in enumerate(vouchers, start=1):
            for line in v.lines:
                is_debit = line.debit > 0
                amount = float(line.debit if is_debit else line.credit)
                rows.append({
                    "TARIH": v.voucher_date,
                    "FIS_NO": f"{v_idx:06d}",
                    "HESAP_KODU": line.account_code,
                    "BA": "B" if is_debit else "A",
                    "TUTAR": amount,
                    "ACIKLAMA": line.description[:50],
                    "BELGE_NO": line.document_no,
                    "BELGE_TARIHI": line.document_date
                })

        df = pd.DataFrame(rows)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Netsis_Fis_Listesi')
        return output.getvalue()
