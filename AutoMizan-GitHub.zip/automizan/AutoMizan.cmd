@echo off
chcp 65001 > nul
title AutoMizan - Mali Müşavir Muhasebe Otomasyon Paneli
echo ========================================================
echo        AutoMizan - Akıllı Muhasebe Motoru
echo   UBL-TR, PDF, OCR, Excel -> TDHP Yevmiye & LUCA Aktarım
echo ========================================================
echo.
echo Uygulama başlatılıyor, lütfen bekleyin...
echo Tarayıcınız otomatik olarak açılacaktır.
echo Adres: http://localhost:8501
echo.

python -m streamlit run automizan\arayuz\app.py --server.port 8501 --browser.serverAddress localhost
pause
